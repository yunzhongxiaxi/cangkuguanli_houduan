package com.proj.invoice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.proj.invoice.bean.allocate;
import org.springframework.stereotype.Component;

@Component
public interface AllocateMapper extends BaseMapper<allocate> {
}
