package com.proj.invoice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.proj.invoice.bean.Repository;
import org.springframework.stereotype.Component;

@Component
public interface RepositoryMapper extends BaseMapper<Repository> {
}
