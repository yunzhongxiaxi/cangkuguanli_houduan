package com.proj.invoice.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.proj.invoice.bean.allocateitems;
import org.springframework.stereotype.Component;

@Component
public interface allocateItemsMapper extends BaseMapper<allocateitems> {
}
