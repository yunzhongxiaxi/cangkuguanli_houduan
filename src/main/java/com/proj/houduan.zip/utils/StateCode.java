package com.proj.invoice.utils;

public interface StateCode {
    public static String pending_submit="待提交";
    public static String pending_review="待审核";
    public static String pending_payment="待支付";
    public static String finished="已完成";
    public static String returned="已退货";

}
